/*
 * PID: 6040474
 */
package ds.asg1;

public interface Bag {
    public boolean isEmpty();
    public void print();
    public void add(String s);
    public void remove(String s);
    int count(String s);
}
